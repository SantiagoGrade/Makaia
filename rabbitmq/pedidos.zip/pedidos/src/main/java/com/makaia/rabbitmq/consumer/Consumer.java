package com.makaia.rabbitmq.consumer;

import com.makaia.rabbitmq.dto.NewOrderDto;
import com.makaia.rabbitmq.dto.ProcessedOrderDto;
import com.makaia.rabbitmq.publisher.Publisher;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class Consumer {

    Publisher publisher;

    @Autowired
    public Consumer(Publisher publisher) {
        this.publisher = publisher;
    }

    @RabbitListener(queues = {"${com.makaia.rabbitmq.queue_nuevo}"})
    public void receiveNew(@Payload long orderId){
        System.out.println("Procesando la información del pedido " + orderId);

        double cost = (Math.random()*10000) + 2000;

        ProcessedOrderDto processedOrderDto = new ProcessedOrderDto(orderId, cost, true);
        System.out.println("Se ha procesado el pedido: " + processedOrderDto.toString());
        this.publisher.sendProccesedOrder(orderId);

    }



}
