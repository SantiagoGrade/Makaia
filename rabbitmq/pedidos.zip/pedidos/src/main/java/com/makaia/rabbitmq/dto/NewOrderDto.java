package com.makaia.rabbitmq.dto;

public class NewOrderDto {
    private long id;
    private double carga;
    private String destino;
    private String origen;

    public NewOrderDto(long id, double carga, String destino, String origen) {
        this.id = id;
        this.carga = carga;
        this.destino = destino;
        this.origen = origen;
    }

    public long getId() {
        return id;
    }

    public double getCarga() {
        return carga;
    }

    public String getDestino() {
        return destino;
    }

    public String getOrigen() {
        return origen;
    }

    @Override
    public String toString() {
        return "NewOrderDto{" +
                "id=" + id +
                ", carga=" + carga +
                ", destino='" + destino + '\'' +
                ", origen='" + origen + '\'' +
                '}';
    }
}
