package com.makaia.rabbitmq.dto;

public class ProcessedOrderDto {
    private long id;
    private double cost;
    private boolean isPayed;

    public ProcessedOrderDto(long id, double cost, boolean isPayed) {
        this.id = id;
        this.cost = cost;
        this.isPayed = isPayed;
    }

    @Override
    public String toString() {
        return "ProcessedOrderDto{" +
                "id=" + id +
                ", cost=" + cost +
                ", isPayed=" + isPayed +
                '}';
    }

    public long getId() {
        return id;
    }

    public double getCost() {
        return cost;
    }

    public boolean isPayed() {
        return isPayed;
    }
}
