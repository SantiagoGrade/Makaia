package com.makaia.rabbitmq.consumer;

import com.makaia.rabbitmq.dto.NewOrderDto;
import com.makaia.rabbitmq.dto.ProcessedOrderDto;
import com.makaia.rabbitmq.publisher.Publisher;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class Consumer {

    Publisher publisher;

    @Autowired
    public Consumer(Publisher publisher) {
        this.publisher = publisher;
    }



    @RabbitListener(queues = {"${com.makaia.rabbitmq.queue_procesado}"})
    public void receiveProcesed(@Payload String message){
        System.out.println("Se genera factura para la orden" + message);
        System.out.println("Emitir nuevo evento de facturaGenerada");
    }


}
